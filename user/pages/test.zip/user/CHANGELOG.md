# v3.0.1
## 27/01/2023

1. [](#improved)
    * Updated Big Picture theme

# v3.0.0
## 27/01/2023

1. [](#improved)
    * Updated Big Picture theme

# v2.0.1
## 18/12/2022

1. [](#improved)
    * Updated Big Picture theme

# v2.0.0
## 31/03/2022

1. [](#improved)
    * Updated Grav, plugins and Big Picture theme

# v1.4.1
## 06/05/2019

1. [](#improved)
    * Updated Grav, plugins and Big Picture theme

# v1.4.0
## 30/03/2018

1. [](#improved)
    * Updated Grav, plugins and Big Picture theme

# v1.2.0
## 05/11/2017

1. [](#improved)
    * Updated Big Picture theme

# v1.1.0
## 05/11/2017

1. [](#improved)
    * Updated Big Picture theme, Grav and plugins

# v1.0.3
## 15/09/2016

1. [](#bugfix)
    * Fixed mixed content issue
    * Fixed contact form for compatibility with new version of Form plugin
    * Updated Grav and plugins

# v1.0.2
## 15/07/2016

1. [](#bugfix)
    * Removed hardcoded content in default.html.twig

# v1.0.1
## 03/06/2016

1. [](#bugfix)
    * Fixed incorrect filename

# v1.0.0
## 02/06/2016

1. [](#new)
    * Skeleton started...
