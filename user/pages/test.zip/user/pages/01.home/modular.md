---
title: Home
content:
    items: '@self.modular'
    order:
        by: default
        dir: asc
        custom:
            - _intro
            - _what-i-do
            - _who-i-am
            - _my-work
            - _contact

---
