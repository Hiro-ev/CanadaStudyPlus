---
title: Intro
heading: Hey.
background_image: intro.jpg
---

Welcome to **Big Picture** skeleton for [Grav CMS](http://getgrav.org)! This skeleton uses **Big Picture** theme which is based on **Big Picture** template designed by [HTML5 UP](http://html5up.net).
